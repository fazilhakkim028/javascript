/*! JsRender
 * Version for web: jsrender.js
 * Version for Node.js (jsrender-node.js): - https://www.npmjs.com/package/jsrender
 */

'use strict';

module.exports = require('./jsrender-node.js');
