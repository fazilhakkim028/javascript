(function() { function _dc(d3, crossfilter) {
'use strict';
